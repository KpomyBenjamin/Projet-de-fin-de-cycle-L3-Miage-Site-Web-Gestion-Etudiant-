<?php
$TrouveUsers=false;
$loginQuery = $db ->prepare (' SELECT login, password FROM users WHERE login = ? AND password = ? LIMIT 1  ');
$loginQuery -> execute([$login,md5($password)]);
$resultat = $loginQuery -> fetchAll();
if(count($resultat) > 0)
{
  header("location:../../EspaceEtudiant/Vue/VueEtudiant/PageAcceuilEtudiant.php");
}else{
  $loginQuery1 = $db ->prepare (' SELECT login, password FROM admin WHERE login = ? AND password = ? LIMIT 1  ');
  $loginQuery1 -> execute([$login,md5($password)]);
  $resultat1 = $loginQuery1 -> fetchAll();
  if(count($resultat1) > 0)
  {
    header("location:../../EspaceEtudiant/Vue/VueEtudiant/AfficheEtudiant.php");
  }else{
    $_SESSION["authentificationError"] = " L'identifiant ou le mot de passe est incorrect" ;
    header("location: ../../");
  }
}

