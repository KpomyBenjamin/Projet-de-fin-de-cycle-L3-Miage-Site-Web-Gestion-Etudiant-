<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$user='root';
$pass='';
$db=null;

      try
      {
       $db = new PDO ('mysql:host=localhost; dbname=gestionecole',$user,$pass); // host c'est pour le nom de l'hôte et dbname c'est pour le nom de la base de données
      }
      catch(PDOexception $a)
      {
         echo " impossible de se connecter à la base de données ";
         exit();
      }