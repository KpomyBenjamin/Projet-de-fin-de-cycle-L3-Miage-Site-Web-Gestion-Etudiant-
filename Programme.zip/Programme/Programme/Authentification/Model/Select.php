<?php 
// On récupère tout le contenu de la table customers
    $var_select = 'SELECT (last_name,first_name,birthday,email,password) FROM customers';// cela signifie prendre le contenu 'first_name', 'last_name' dans la table customers
    $prepare = $db->prepare($var_select);// Prepare averti les champs de identifiés dans la requête $var_select ou le prepare à être utiliser
    $prepare->execute();// exécute la requête
    $recepteur = $prepare->fetchAll(); // la fonction fetchAll signifie d'aller chercher dans la table

    // On affiche chaque recette une à une
    foreach ($recepteur as $contain) 
        {
        // Format writen
    echo " {$contain['first_name']} {$contain['last_name']} <br> " ;
    }