<?php
    require_once("DataBaseConnect.php");
    $passQuery= $db ->prepare("Select login FROM users WHERE login = ? LIMIT 1");
    $passQuery->execute([$login]);
    $resultat=$passQuery->fetchAll();
    if(count($resultat)>0)
    {
        $_SESSION["userError"]="Nom user existant";
    }else
    {
        // les requête sql
        $query=("INSERT INTO users (nom,login,password) VALUES (?,?,?)");/*les points d'intérogation signifie que les informations doivent 
        être entrées par le users */
        $preparation = $db->prepare($query);// on prepare la variable ou on l'avertit
        $preparation->execute([$nom,$login,md5($password)]);

    }
