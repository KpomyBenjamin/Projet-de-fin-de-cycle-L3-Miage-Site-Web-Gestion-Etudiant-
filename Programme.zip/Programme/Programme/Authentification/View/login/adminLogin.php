<?php 
  session_start();
  include_once("../Entete.php");
?>
<Doctype html>
  <head>
    <meta charset="uft-8">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <!-- <link rel="stylesheet" href="../inscription/inscription.css"> -->
    <link rel="stylesheet" href="../bootstrap.min.css">
    <title>Admin</title>
  </head>
  <body>
    <div class="container col-xs-10 col-sm-8 col-md-6 spacer col-xs-offset-1 col-sm-offset-2 col-md-offset-3">
      <div class="panel panel-default">
        <div class="panel-heading" >Espace Administrateur</div>
          <div class="panel-body">
            <form method= "post" action="../../Controler/SuperAdmin.php" enctype="multipart/form-data">
              <!-- pour le nom -->
              <div class="form-group">
                <label class="control-label">Username</label>
                <input type="text" name="username" class="form-control">

              </div>
              <!-- pour l'email -->
              <div class="form-group">
                <label class="control-label">Password</label>
                <input type="text" name="password" class="form-control">

              </div>
              <div class="form-group">
                <button type="submit" name="submit" class="btn btn-success">Log in</button>  
              </div>
                          
              <!-- Affichage de l'erreur -->
              <?php if(isset($_SESSION["loginError"])) echo "<div class='text-white bg-danger p-3 col-12'>".$_SESSION['loginError']."</div>";
                unset($_SESSION["loginError"]);

                // Affichage de l'erreur d'authentification
                if(isset($_SESSION["AdminError"])) echo "<div class='loginError'>".$_SESSION["AdminError"]."</div>";
                unset($_SESSION["AdminError"]);
              ?>
            </form>
          </div> 
        </div>
      </div> 
    </div>
  </body>
</html>



        
