<?php 
  session_start();
?>

<div class="gy-10">
  <div class="container mt-100">
    <h1 class=" text-center texte- fw-bolder bg-info p-10 width=100% rounded-5">BIENVENUE DANS VOTRE PORTAIL ETUDIANT</h1>
  </div>

  <div class="container mt-100 col-xs-10 col-sm-8 col-md-6 spacer col-xs-offset-1 col-sm-offset-2 col-md-offset-3">
    <div class="panel panel-default">
      <div class="panel-heading" >Se Connecter</div>
        <div class="panel-body">
          <form method= "post" action="Authentification/Controler/LoginControl.php" enctype="multipart/form-data">
            <!-- pour le nom -->
            <div class="form-group">
                <label class="control-label">Username</label>
                <input type="text" name="login" class="form-control">

            </div>
            <!-- pour l'email -->
            <div class="form-group">
                <label class="control-label">Password</label>
                <input type="text" name="password" class="form-control">

            </div>
            <div class="form-group">
              <button type="submit" name="submit" class="btn btn-success">Log in</button>
              <!-- Lien pour creer un compte-->   
              <a href="Authentification/View/inscription/inscription.php" class="btn btn-primary">Create New Account</a>
              <a href="Authentification/View/login/adminLogin.php" class="btn btn-secondary">Admin ?</a>
            </div>
                        
            <!-- Affichage de l'erreur -->
            <?php if(isset($_SESSION["loginError"])) echo "<div class='loginError'>".$_SESSION['loginError']."</div>";
              unset($_SESSION["loginError"]);

              // Affichage de l'erreur d'authentification
              if(isset($_SESSION["authentificationError"])) echo "<div class='loginError'>".$_SESSION["authentificationError"]."</div>";
              unset($_SESSION["authentificationError"]);
            ?>
          </form>
        </div> 
      </div>
    </div> 
  </div>
</div>



        
