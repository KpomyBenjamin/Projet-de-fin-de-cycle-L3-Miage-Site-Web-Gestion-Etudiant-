<?php 
  session_start();
  include_once("../Entete.php");
?>
<Doctype html>
  <head>
    <meta charset="uft-8">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <!-- <link rel="stylesheet" href="inscription.css"> -->
    <link rel="stylesheet" href="../bootstrap.min.css">
    <title> Mon app</title>
  </head>
  <body>
    <div class="container col-xs-10 col-sm-8 col-md-6 spacer col-xs-offset-1 col-sm-offset-2 col-md-offset-3">
      <div class="panel panel-default">
        <div class="panel-heading" >Inscription</div>
          <div class="panel-body">
            <form method= "post" action="../../Controler/InscriptionControl.php" enctype="multipart/form-data">
              <!-- pour le nom -->
              <div class="form-group">
                <label class="control-label">Nom</label>
                <input type="text" name="nom" class="form-control">
              </div>

              <!-- pour le login -->
              <div class="form-group">
                <label class="control-label">Username</label>
                <input type="text" name="login" class="form-control">
              </div>

              <!-- pour mot de passe -->
              <div class="form-group">
                <label class="control-label">Password</label>
                <input type="text" name="password" class="form-control">
              </div>  

              <!-- pour confirmation mot de passe -->
              <div class="form-group">
                <label class="control-label">Confirm Password</label>
                <input type="text" name="confirmpassword" class="form-control">
              </div>

              <div class="form-actions">
                <button type="submit" name="submit" class="btn btn-success">S'inscrire</button>
                <!-- Lien pour creer un compte-->   
                <a href="../../../" class="btn btn-primary">Login</a>
              </div>
                          
              <!-- Affichage de l'erreur au cas ou les champs sont vides -->
              <?php if(isset($_SESSION["inscriptionError"])) echo "<div class='inscriptionError'>".$_SESSION['inscriptionError']."</div>";
                unset($_SESSION["inscriptionError"]);
                
                // Affichage de l'erreur du mail 
                if(isset($_SESSION["passError"])) echo "<div class='inscriptionError'>".$_SESSION["passError"]."</div>";
                unset($_SESSION["passError"]);

                // Affichage de l'erreur de la confirmation du mot de pass
                if(isset($_SESSION["mailError"])) echo "<div class='inscriptionError'>".$_SESSION["mailError"]."</div>";
                unset($_SESSION["mailError"]);
              ?>
            </form>
          </div> 
        </div>
      </div> 
    </div>
  </body>
</html>