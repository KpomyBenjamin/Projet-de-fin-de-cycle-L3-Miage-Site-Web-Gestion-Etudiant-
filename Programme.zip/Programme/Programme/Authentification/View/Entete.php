<div class="navbar navbar-inverse navbar-fixed-top-right">
    <ul class="nav navbar-nav">
        <li><a href="../../../">LogOut</a></li>
    </ul>
</div>