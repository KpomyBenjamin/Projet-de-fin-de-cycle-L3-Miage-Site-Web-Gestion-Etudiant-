<?php
// On ouvre la session
session_start();

// Appel de la fonction
include("DataControlFonction.php");

// Control des saisies de l'utilisateur
if(isset($_POST["submit"]))
{
    if(empty($_POST["username"] && $_POST["password"]))
    {
        $_SESSION["loginError"]="Veuillez remplir tous les champs ";
        header("location: ../View/login/adminLogin.php");
    }else
    {
        $username=checkData($_POST["username"]);
        $password=checkData($_POST["password"]);
        if($username == "root" && $password == "root"){
            $_SESSION["admin"] = "oui";
            header("location: ../../EspaceEtudiant/Vue/VueEtudiant/AfficheEtudiant.php");
        }else{
            $_SESSION["AdminError"] = "Login ou mot de passe eroné !!!";
            header("location: ../View/login/adminLogin.php");
        }
        
    }
}
