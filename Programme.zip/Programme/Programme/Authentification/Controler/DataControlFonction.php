<?php
/** 
 * Fonction pour annuler l'injection des balises ou des scripts dans les champs de saisie
 * @method chekData()
 * @param $data
 * @return $data
 */

function checkData($data)
{
    $data=trim($data);
    $data=stripslashes($data);
    $data=htmlspecialchars($data);
    return $data;
}