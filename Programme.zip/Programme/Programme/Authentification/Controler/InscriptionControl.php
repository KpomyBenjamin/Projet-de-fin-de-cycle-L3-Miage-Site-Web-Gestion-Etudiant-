<?php
// On ouvre la session
session_start();
// Appel de la fonction pour controller notre saisie
include("DataControlFonction.php");

// Control des saisies de l'utilisateur
if(isset($_POST["submit"]))
{
    if(empty($_POST["nom"] && $_POST["login"] && $_POST["password"] && $_POST["confirmpassword"]))
    {
        $_SESSION["inscriptionError"]="Veuillez remplir tous les champs ";
    }else
    {
        $nom=checkData($_POST["nom"]);
        $login=checkData($_POST["login"]);
        $password=checkData($_POST["password"]);
        $confirmpassword=checkData($_POST["confirmpassword"]);
        
        // Verifions si les mots de pass sont identiques
        if($password != $confirmpassword)
        {
            $_SESSION["passError"]=" Les mots de pass ne sont pas identiques";
        }
        else
        {
            include("../Model/Insert.php");
            header("location: ../../EspaceEtudiant/Vue/VueEtudiant/AfficheEtudiant.php");
        }   
    }
}
header("location: ../View/inscription/inscription.php");

?>
