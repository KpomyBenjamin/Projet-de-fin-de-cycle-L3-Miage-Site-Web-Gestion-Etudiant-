<?php
// On ouvre la session
session_start();
include("../Model/DataBaseConnect.php");

// Appel de la fonction
include("DataControlFonction.php");

// Control des saisies de l'utilisateur
if(isset($_POST["submit"]))
{
    if(empty($_POST["login"] && $_POST["password"]))
    {
        $_SESSION["loginError"]="Veuillez remplir tous les champs ";
        header("location: ../../");
    }else
    {
        $login=checkData($_POST["login"]);
        $password=checkData($_POST["password"]);
        require_once("../Model/authentification.php");
    }
}
