<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facebook</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="Authentification/View/bootstrap.min.css">
</head>
<body>
    <?php include_once("Authentification/View/login/login.php")?>
</body>
</html>