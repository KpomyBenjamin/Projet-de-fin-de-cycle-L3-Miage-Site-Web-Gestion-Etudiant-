<?php
    try {
        $DataBase = new PDO("mysql:host=localhost;dbname=gestionecole",'root','');
        $DataBase->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        // echo "Connexion reussit à la base de donnée";
    } catch (PDOException $e) {
        die('Erreur :'.$e->getmessage());
        //echo "Erreur de connexion à la base de donnée";
    }
?>