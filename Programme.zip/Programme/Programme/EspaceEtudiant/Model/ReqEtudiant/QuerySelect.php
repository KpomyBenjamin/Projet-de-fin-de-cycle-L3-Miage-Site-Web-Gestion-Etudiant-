<?php
      //Connexion à la base de donnée 
    require_once('../../Model/Connexion.php');
    $preparation=$DataBase->prepare("SELECT *FROM etudiant WHERE code=?");
     //Creation d'un tableau de parametre
    $params=array($_SESSION["code"]);
     // Execution
    $preparation->execute($params);
    //
    $et=$preparation->fetch();
?>