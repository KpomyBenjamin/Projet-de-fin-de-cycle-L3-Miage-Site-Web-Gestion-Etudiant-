<?php
       require_once("../../Model/ReqEtudiant/QueryAffiche.php");
       $preparation=$DataBase->prepare("DELETE FROM etudiant WHERE code=?");
       $params=array($CODE);
       $preparation ->execute($params);
?>