<?php
    //Connexion à la base de donnée 
    require_once('../../Model/Connexion.php');
    $preparation=$DataBase->prepare("INSERT INTO etudiant(nom,email,photo)VALUES(?,?,?)");
    //Creation d'un tableau de parametre
    $params=array($nom,$email,$nomphoto);
    // Execution
    $preparation->execute($params);
  
?>