<?php
    require_once("../../Model/Connexion.php");
    $preparation=$DataBase->prepare("SELECT * FROM etudiant");
    $preparation->execute();
?>