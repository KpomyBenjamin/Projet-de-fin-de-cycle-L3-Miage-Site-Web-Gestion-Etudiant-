<?php
     //Deplacement des fichiers"Photo" dans mon dossier temporaire
     require_once("../../Model/Connexion.php");
    if($nomphoto==""){
      $preparation=$DataBase->prepare("UPDATE etudiant SET nom=?, email=? where code=?");
      $params=array($nom,$email,$_SESSION["code"]);
      $preparation->execute($params);
      header('location:../../Vue/VueEtudiant/AfficheEtudiant.php');
    }else{
        move_uploaded_file( $fichierTemp, '../../Vue/VueEtudiant/images/'.$nomphoto);
        $preparation=$DataBase->prepare("UPDATE etudiant SET nom=?,email=?,photo=? where code=?");
        $params=array($nom,$email,$nomphoto,$_SESSION["code"]);
        $preparation->execute($params);
        header('location:../../Vue/VueEtudiant/AfficheEtudiant.php');
    }
?>
