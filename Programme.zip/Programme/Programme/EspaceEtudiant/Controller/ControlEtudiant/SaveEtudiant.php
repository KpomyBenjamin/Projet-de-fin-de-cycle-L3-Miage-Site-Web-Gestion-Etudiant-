<?php
    //Recuperation des données afin d'envoyer dans le formulaire "Etudiant"
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $photo = $_POST['photo'];
    $nomphoto = $_FILES['photo']['name'];
    $fichierTemp = $_FILES['photo']['tmp_name'];
    //Deplacement des fichiers"Photo" dans mon dossier temporaire
    move_uploaded_file( $fichierTemp, '../../Vue/VueEtudiant/images/'.$nomphoto);
    //echo ($fichierTemp);
    require_once("../../Model/ReqEtudiant/QueryInsertion.php");
    header('location:../../Vue/VueEtudiant/AfficheEtudiant.php');

?>