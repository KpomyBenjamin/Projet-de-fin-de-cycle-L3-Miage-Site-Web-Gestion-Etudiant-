<?php
session_start();
    //Recuperation des données afin d'envoyer dans le formulaire "Etudiant"
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $nomphoto = $_FILES['photo']['name'];
    $fichierTemp = $_FILES['photo']['tmp_name'];
    //Deplacement des fichiers"Photo" dans mon dossier temporaire
    require_once("../../Model/ReqEtudiant/QueryUpdate.php");    
    

?>