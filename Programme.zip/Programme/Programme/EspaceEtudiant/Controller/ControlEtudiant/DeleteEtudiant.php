<?php
    //Recuperation de la variable declarée dans l'URL
    $CODE=$_GET['CODE'];
   
  require_once("../../Model/ReqEtudiant/QueryDelete.php");
    header('location:../../Vue/VueEtudiant/AfficheEtudiant.php');
?>