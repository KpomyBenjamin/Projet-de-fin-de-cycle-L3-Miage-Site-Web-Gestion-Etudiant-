<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/mystyle.css">
    <link rel="stylesheet" type="text/css" href="Font-Awesome-6.x/css/all.min.css">
    <script type="text/javascript" src="Font-Awesome-6.x/css/all.min.js"></script>
    <title>Saisie</title>
</head>
<body>
    <?php require_once('EntetePage.php') ?>
    <div class=" container col-xs-10 col-sm-8 col-md-6 spacer col-xs-offset-1 col-sm-offset-2 col-md-offset-3">
        <div class="panel panel-default">
            <div class="panel-heading" >Ajouter un Etudiant</div>
            <div class="panel-body">
                <form method= "post" action="../../Controller/ControlEtudiant/SaveEtudiant.php" enctype="multipart/form-data">
                    <!-- pour le nom -->
                    <div class="form-group">
                        <label class="control-label">NOM :</label>
                        <input type="text" name="nom" class="form-control">

                    </div>
                    <!-- pour l'email -->
                    <div class="form-group">
                        <label class="control-label">E-MAIL :</label>
                        <input type="text" name="email" class="form-control">

                    </div>
                    <!-- pour la photo -->
                    <div class="form-group">
                        <label class="control-label">PHOTO :</label>
                        <input type="file" name="photo" class="form-control">

                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</body>
</html>