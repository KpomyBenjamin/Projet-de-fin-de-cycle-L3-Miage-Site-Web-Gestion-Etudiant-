<?php
session_start();
    require_once("../../Model/ReqEtudiant/QueryAffiche.php");
    require_once("EntetePage.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/mystyle.css">

    <link rel="stylesheet" type="text/css" href="Font-Awesome-6.x/css/all.min.css">
    <script type="text/javascript" src="Font-Awesome-6.x/css/all.min.js"></script>
    <title>Etudiant</title>

</head>
<body>
    <div class="col-md-12 col-xs-6 spacer">
        <div class="panel panel-info ">
            <div class="panel-heading">Liste des étudiants</div>
            <div class="panel-body">

            </div>
            <table class="table table-striped">
        <thead>
            <tr>
                <th>CODE</th>
                <th>NOM</th>
                <th>EMAIL</th>
                <th>PHOTO</th>
                <th>ACTION</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while ($et=$preparation->fetch())
                {?>
                    <tr>
                        <td><?php echo($et['code'])?></td>
                        <td><?php echo($et['nom'])?></td>
                        <td><?php echo($et['email'])?></td>
                        <td><img src="images/<?php echo($et['photo'])?>" width="100" height="100"></td>
                        <!--  -->
                        <td><a href="ModifierEtudiant.php?CODE=<?php echo($et['code'])?>" class="btn btn-primary"><i class="fas fa-edit"></i></a></td>
                        
                        <td><a onclick="return confirm('Etes-vous sur de supprimer cet étudiant...')" href="../../Controller/ControlEtudiant/DeleteEtudiant.php?CODE=<?php echo($et['code'])?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a></td>
                    </tr>

              <?php  }
            ?>
            <!-- <tr>Contenu</tr> -->
        </tbody>
    </table>
        </div>
    </div>
   
</body>
</html>