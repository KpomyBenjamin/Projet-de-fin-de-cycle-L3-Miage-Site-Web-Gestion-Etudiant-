<div class="navbar navbar-inverse navbar-fixed-top-right">
    <ul class="nav navbar-nav">
        <li><a href='../../../Authentification/View/inscription/inscriptionAdmin.php'>Creer Admin</a></li>
        <li><a href='AfficheEtudiant.php'>Etudiants</a></li>
        <li><a href='SaisieEtudiant.php'>Inscription</a></li>
        <li><a href="LogOut.php">LogOut</a></li>
    </ul>
</div>