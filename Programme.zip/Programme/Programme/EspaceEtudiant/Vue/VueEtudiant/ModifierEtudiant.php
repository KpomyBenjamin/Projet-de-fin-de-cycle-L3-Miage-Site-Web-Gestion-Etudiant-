<?php
session_start();
 require_once('EntetePage.php');
    $_SESSION["code"]=$_GET['CODE'];
    require_once("../../Model/ReqEtudiant/QuerySelect.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="Font-Awesome-6.x/css/all.min.css">
    <script type="text/javascript" src="Font-Awesome-6.x/css/all.min.js"></script>
    <title>Ajouter un Etudiant</title>
</head>
<body>
    
    <div class=" container col-md-6 col-xs-12 spacer col-md-offset-3">
        <div class="panel panel-default">
            <div class="panel-heading">Ajouter un Etudiant</div>
                <div class="panel-body">
                
                    <form method="POST"action="../../Controller/ControlEtudiant/UpdateEtudiant.php"enctype="multipart/form-data">
                        <div class="form-group">
                            <label class="control-label">Nom:</label>
                            <input type="text"name="nom"class="form-control"placeholder="Votre nom"value="<?php echo($et['nom'])?>">
                        </div>
                        <div class="form-group">
                            <label class="control-label">email:</label>
                            <input type="text"name="email"class="form-control"placeholder="Votre Email"value="<?php echo($et['email'])?>">

                        </div>
                        <div class="form-group">
                            <label class="control-label">Photo:</label>
                            <input type="file"name="photo"class="form-control"placeholder="Votre Photo" value="<?php echo($et['photo']) ?>">

                        </div>
                        <div class="form-actions">
                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-pencil"></span>Ajouter</button>
                            <a class="btn btn-primary"href="AfficheEtudiant.php"><span class="glyphicon glyphicon-arrow-left"></span>Retour</a>
                        </div> 
                    </form>  
                
                 </div>
            </div>
         </div>
    </div>
</body>
</html>